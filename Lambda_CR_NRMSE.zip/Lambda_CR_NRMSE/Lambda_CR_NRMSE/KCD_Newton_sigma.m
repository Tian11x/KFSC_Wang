function [D,W]=KCD_Newton_sigma(Y,lambda,sigma,atoms,iter,exit_tol)

%% Parameter initialization
[rows_y,columns_y]=size(Y);

%% Dictionary matrix initialization
D0=rand(rows_y,atoms);
D=zeros(rows_y,atoms);
for i=1:atoms
    D(:,i)=D0(:,i)./norm(D0(:,i),2);
end
% D=eye(atoms);
KDD=kernel_rbf_sigma(sigma,D,D);
KYD=kernel_rbf_sigma(sigma,Y,D);

%% =======================phi(Y)=phi(D)W=========================
W=zeros(atoms,columns_y);
for h=1:iter
    %% Sparse coding
    W_old=W;
    for c=1:columns_y
        KyD=KYD(c,:);
        for i=1:atoms
            z=KyD(i)-KDD(i,:)*W(:,c)+KDD(i,i)*W(i,c);
            if z>lambda
                W(i,c) = z-lambda;
            elseif z<-lambda
                W(i,c) = z+lambda;
            else
                W(i,c) = 0;
            end
        end
    end
    
    %% Dictionary Learning
    D_old=D;
    Q1=W'.*KYD;
    Gamma1=diag(sum(Q1,1));
    Q2=W*W'.*KDD;
    Gamma2=diag(sum(Q2,1));
    GD=(1/sigma^2)*(D*Gamma1-Y*Q1+D*Q2-D*Gamma2); 
    HD=(1/sigma^2)*(Gamma1+Q2-Gamma2);
    t=1.1*norm(HD,2);
    D=D-GD/t;
    %---------------------
    for t=1:atoms
        D(:,t)=D(:,t)./norm(D(:,t),2);
    end
    %---------------------
    KYD=kernel_rbf_sigma(sigma,Y,D);
    KDD=kernel_rbf_sigma(sigma,D,D);
    
    %% Stopping condition
    Object(h)=columns_y-trace(2*KYD*W)+trace(W'*KDD*W); 
    if h>1
        error1=Object(h)-Object(h-1);
        error2=norm(D-D_old,'fro')/norm(D_old,'fro');
        if  error1< exit_tol && error2 < exit_tol
            fprintf('KCD_Newton_sigma reached exit tolerance at iter %d\n',h);
            break
        end
    end
end
end
