clear;clc;

%% Parameter initialization
exit_tol=1e-4;
iter=200;
atoms=226;

%% 
load('D:\Dataset\��ʦ��\Harvard226\Harvard.mat')
Q=data;

%% Test data --Z
Z0 = squeeze(Q(:, :, 2));
[rows_z,columns_z]=size(Z0);
Z=zeros(rows_z,columns_z);
for i=1:columns_z
    Z(:,i)=Z0(:,i)./norm(Z0(:,i));
end

%%
load('D_KCD.mat');
load('sparsity')
sigma=1:15;

for L=1:length(sigma)
    KDD=kernel_rbf_sigma(sigma(L),D,D);
    KZD=kernel_rbf_sigma(sigma(L),Z,D);
    
    %%
    W_KPAM=KPAM(Z,KZD,KDD,atoms,iter,exit_tol,sparsity);
    Object_KPAM(L)=columns_z-trace(2*KZD*W_KPAM)+trace(W_KPAM'*KDD*W_KPAM);
    Z_KPAM1=[];
    for j=1:columns_z
        w=W_KPAM(:,j);
        z_KPAM1=y_KGD(D,KDD,w,sigma(L),iter,exit_tol);
        Z_KPAM1=[Z_KPAM1 z_KPAM1];
    end
    LOSS_KPAM(L)=norm(Z-Z_KPAM1,'fro')/norm(Z,'fro');
end

figure;
plot(sigma,Object_KPAM,'-o', 'LineWidth', 2)