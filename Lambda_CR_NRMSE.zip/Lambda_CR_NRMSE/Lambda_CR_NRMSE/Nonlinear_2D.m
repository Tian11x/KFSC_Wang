clc;clear;  
lambda=0.05;
sigma=2;
iter=100;
exit_tol=0.001;

for k=1:1000
    y1=rand(1,6);
    y2=y1.^2+0.1;
    Y=[y1;y2];
    
%     disp('Random points on the upper hemisphere of a unit sphere:');
%     disp(points);
    
    atoms=5; % size(Y,1);
    [D1,W1,NRMSE1,LOSS1]=CD_Newton(Y,atoms,0.01,iter,exit_tol);
    Nonzero1=W1~=0; 
    No1=sum(Nonzero1(:));
    
%     Z=[Y; Y(1,:).^2; Y(2,:).^2; Y(3,:).^2; Y(1,:).*Y(2,:); Y(1,:).*Y(3,:); Y(2,:).*Y(3,:)];
%     atoms2=size(Z,1);
%     [D2,W2,NRMSE2,LOSS2]=CD_Newton(Z,atoms2,lambda,iter,exit_tol);
%     Nonzero2=W2~=0;  Nonzero22=W2==0;
%     No2=sum(Nonzero2(:));  No22=sum(Nonzero22(:));
   [U,W2]=KCD_Newton_sigma(Y,0.05,sigma,atoms,iter,exit_tol);
   Z=[Y; Y(1,:).^2; Y(2,:).^2; Y(1,:).*Y(2,:)];
   D2=[U; U(1,:).^2; U(2,:).^2; U(1,:).*U(2,:)];
   LOSS2=0.5*norm(Y-U*W2,'fro')^2;
   Nonzero2=W2~=0; 
   No2=sum(Nonzero2(:));  
   NRMSE2=norm(Z-D2*W2,'fro')/norm(Z,'fro');
    
    if No2<No1 && No2<numel(Y)  % && LOSS2<=LOSS1
        break
    end
end
Y
W1
W2
