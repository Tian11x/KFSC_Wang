function [D,W,NRMSE,LOSS]=CD_Newton(Y,atoms,lambda,iter,exit_tol)

[rows_Y,columns_Y]=size(Y);

%% Initialize Dictionary  
D0=rand(rows_Y,atoms);
D=zeros(rows_Y,atoms);
for i=1:atoms
    D(:,i)=D0(:,i)./norm(D0(:,i));
end

%% ===================="Y=DW"===================
%% To obtain the dictionary matrix D
 W=zeros(atoms,columns_Y);
for h=1:iter
    DD=D'*D;
    D_col_norm=diag(DD);
    %% sparse coding
    W_old=W;
    for c=1:columns_Y
        y=Y(:,c);
        yD=y'*D;
        for i = 1 : atoms
            z=yD(i)-DD(i,:)*W(:,c)+W(i,c)*D_col_norm(i);
            if z>lambda
                W(i,c) = (z-lambda)/D_col_norm(i);
            elseif z<-lambda
                W(i,c) = (z+lambda)/D_col_norm(i);
            else
                W(i,c) = 0;
            end
        end
        %-----------�˴���Ϊ��ά������Ҫ-------------
%         w=W(:,c);
%         [~, ind] = sort(w, 'descend');
%         topSInd = ind(1:2);
%         result = zeros(atoms,1);
%         result(topSInd) = w(topSInd);
%         W(:,c)=result;
        %------------------------
    end
    
    %% Dictionary Learning
    D_old=D;
    GD=-Y*W'+D*W*W';
    HD=W*W';
    D=D-GD/(1.1*norm(HD,2));
    %---------------------
    for t=1:atoms
        D(:,t)=D(:,t)./norm(D(:,t),2);
    end
    %---------------------
    
    %% Stopping condition
    Object(h)=norm(Y-D*W,'fro')/norm(Y,'fro');
    if h>1
        error1=Object(h)-Object(h-1);
        error2=norm(D-D_old,'fro')/norm(D_old,'fro');
        if error1< exit_tol && error2 < exit_tol
            fprintf('CD_KSVD reached exit tolerance at iter %d\n',h);
            break
        end
    end
end
NRMSE=norm(Y-D*W,'fro')/norm(Y,'fro');
LOSS=0.5*norm(Y-D*W,'fro')^2;
end