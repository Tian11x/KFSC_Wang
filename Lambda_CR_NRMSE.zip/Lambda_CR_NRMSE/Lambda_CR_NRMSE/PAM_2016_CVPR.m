function D=PAM_2016_CVPR(Y,atoms,sigma,iter,exit_tol) % lambda �� sparsity ������

%% Parameter initialization
[rows_y,columns_y]=size(Y);

%% D_init
D0=rand(rows_y,atoms);
D=zeros(rows_y,atoms);
for i=1:atoms
    D(:,i)=D0(:,i)./norm(D0(:,i));
end
KYD=kernel_rbf_sigma(sigma,Y,D);
KDD=kernel_rbf_sigma(sigma,D,D);

%% W_init
W=zeros(atoms,columns_y);

%% =======================phi(Y)=phi(D)W=========================
for h=1:iter
    %% Sparse coding
    W_old=W;
    s=1.1*max(eig(KDD)); % ����
    W=W-(-KYD'+KDD*W)/s;
    
    %% Dictionary Learning
    D_old=D;
    Q1=W'.*KYD;
    Gamma1=diag(sum(Q1,1));
    Q2=W*W'.*KDD;
    Gamma2=diag(sum(Q2,1));
    GD=(1/sigma^2)*(D*Gamma1-Y*Q1+D*Q2-D*Gamma2);
    t=1.1*norm((1/sigma^2)*(Gamma1+Q2-Gamma2),2);
    D=D-GD/t;
    %---------------------
    for t=1:atoms
        D(:,t)=D(:,t)./norm(D(:,t),2);
    end
    %---------------------
    KYD=kernel_rbf_sigma(sigma,Y,D);
    KDD=kernel_rbf_sigma(sigma,D,D);
    
    %% Stopping condition
%     errorD(h)=norm(D-D_old,'fro')/norm(D_old,'fro');
%     errorW(h)=norm(W-W_old,'fro')/norm(W_old,'fro');
%     loss(h)=columns_y-trace(2*KYD*W)+trace(W'*KDD*W);
    %     if error(h) < exit_tol
    %             fprintf('PAM_2016_CVPR reached exit tolerance at iter %d\n',h);
    %             break
    %     end
end
end