% function KXY=kernel_rbf(X,Y)
% nx=size(X,2);
% ny=size(Y,2);
% xx=sum(X.^2,1);
% yy=sum(Y.^2,1);
% D=repmat(xx',1,ny) + repmat(yy,nx,1) - 2*X'*Y; %-------------�Խ����з���Ԫ----------
% sigma2=(mean(real(D(:).^0.5)))^2;% sigma^2
% % sigma2=mean(D);
% KXY=exp(-D/2/sigma2);
% end

function KXY=kernel_rbf(X,Y)
p1=size(X,2);
p2=size(Y,2);
for i=1:p1
    for j=1:p2
        temp0=X(:,i)-Y(:,j);
        temp(i,j)=-norm(temp0,2)^2;
        KXY(i,j)=exp(temp(i,j)/2);
    end
end
end

% sigma2=(mean(real(temp(:).^0.5)))^2;  % sigma^2
% sigma2=mean(temp(:));
% sigma2=1;
% sigma2=max(temp(:));
% sigma2=min(temp(:)); % =0
% nonzero_elements = temp(temp > 0);
% min_nonzero_value = min(nonzero_elements);
% [min_row, min_col] = find(temp == min_nonzero_value);