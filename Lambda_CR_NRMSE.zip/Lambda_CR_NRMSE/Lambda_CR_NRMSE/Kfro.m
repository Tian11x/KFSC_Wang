function W=Kfro(Z,KDD,KZD,atoms,lambda,iter,exit_tol,sparsity)
%% Initialize
columns_z=size(Z,2);
W=zeros(atoms,columns_z);

%% KSR_norm21
for h=1:iter
    W_old=W;
    W=pinv(KDD+2*lambda*eye(atoms))*KZD';
    %-------------------------------------------------
    for c=1:columns_z
        w=W(:,c);
        w_abs21=abs(w);
        [~, ind] = sort(w_abs21, 'descend');
        topSInd = ind(1:sparsity(c));
        result = zeros(atoms,1);
        result(topSInd) = w(topSInd);
        W(:,c)=result;
    end

    %%  stopping criterion
    loss(h)=columns_z-trace(2*KZD*W)+trace(W'*KDD*W);
    if h>1
        error=abs(loss(h)-loss(h-1));
        Error_W = norm(W-W_old,'fro')/norm(W_old,'fro');
        if  error<exit_tol && Error_W < exit_tol
            fprintf('Kfro reached exit tolerance at iter %d\n',h);
            break;
        end
    end
end
end