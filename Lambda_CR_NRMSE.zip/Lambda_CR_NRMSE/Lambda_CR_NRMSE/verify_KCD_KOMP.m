clear;clc;
rng(1)
D = randi([1, 10], 4, 4); 
for i=1:4
    D(:,i)=D(:,i)./norm(D(:,i),2);
end

w0=[0.2,0,0.8,0.5]';
z=D*w0;
z=z./norm(z,2);

atoms=4;

exit_tol=1e-3;
iter=100;
sigma=1.5;
lambda=0.01;

KDD=kernel_rbf_sigma(sigma,D,D);
KzD=kernel_rbf_sigma(sigma,z,D);
    
w_KCD=KCD(atoms,KzD,KDD,lambda,iter,exit_tol);
sparsity=sum(w_KCD~=0);
w_KOMP=KOMP2(z,KDD,KzD,atoms,sparsity);

Object_KCD=1-trace(2*KzD*w_KCD)+trace(w_KCD'*KDD*w_KCD);
Object_KOMP=1-trace(2*KzD*w_KOMP)+trace(w_KOMP'*KDD*w_KOMP);



