function Z=Z_KGD(D,W,KDD,sigma,iter,exit_tol)

sigma2=sigma^2;  % rbf hyperparameters
[rows_D,~]=size(D);
[~,cols_W]=size(W);
%% initialize
Z=rand(rows_D,cols_W);
KZD=kernel_rbf_sigma(sigma,Z,D);
KDZ=KZD';
for h=1:iter;
    Z_old=Z;
    GZ=1/sigma2*Z*((KZD*W).*eye(cols_W))-1/sigma2*D*(KDZ.*W);
    HZ=(KZD*W).*eye(cols_W);
    t=1.1*max(max(HZ));
    Z=Z-GZ/t;
    KZD=kernel_rbf_sigma(sigma,Z,D);
    %% stopping criterion1
    loss(h)=0.5*cols_W-trace(KZD*W)+0.5*trace(W'*KDD*W);
    if h>1
        error=abs(loss(h)-loss(h-1));
        if  error<exit_tol
            fprintf('Z_KGD reached exit tolerance at iter %d\n',h);
            break;
        end
    end
    %% stopping criterion2
%     error=norm(Z-Z_old,2)/norm(Z_old,2);
%     if error < exit_tol
%         fprintf('Z_KGD reached exit tolerance at iter %d\n',h);
%         break
%     end
end

end