% KOMP for "phi(Y)=phi(D)W" 
% 2015=Inf. Sci.=Kernel sparse representation for time series classification (KOMP, yes)
function W=KOMP2(Y,KDD,KYD,atoms,sparsity) 
%% Initialize
columns_Y=size(Y,2);
I=1:atoms;
KDY=KYD';

%% KOMP2
W=[];
for c=1:columns_Y  % Y��ÿһ��
    Is=[];
    Ic=setdiff(I,Is);
    tao=KYD(c,:); 
    for s=1:sparsity(c)  % sparsity(c)����Ϊ0
        [~,ind] = max(abs(tao));
        Is = [Is ind];
        ws=pinv(KDD(Is,Is))*KDY(Is,c);
        
        Ic=setdiff(I,Is);
        tao=zeros(1,atoms);
        for i=Ic;
            tao(i)= KYD(c,i)-ws'*KDD(Is,i);
        end 
    end
    w=zeros(atoms,1);
    w(Is)=ws;
    W=[W w];
end
end
