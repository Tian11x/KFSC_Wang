clear;clc;

%% Parameter initialization
exit_tol=1e-3;
iter=200;
lambda=0.002:0.002:0.1;  % 0.001��0.005��0.01��0.05��0.1��0.5��1

%% Train data --Y
Y0 = load('D:\Dataset\NetLatency-Data-master\Seattle\SeattleData_1');
[rows_y,columns_y]=size(Y0);
Y=zeros(rows_y,columns_y);
for i=1:columns_y
    Y(:,i)=Y0(:,i)./norm(Y0(:,i));
end

atoms=rows_y;
nY=numel(Y);

%% Test data --Z
Z0 = load('D:\Dataset\NetLatency-Data-master\Seattle\SeattleData_2'); 
[rows_z,columns_z]=size(Z0);
Z=zeros(rows_z,columns_z);
for i=1:columns_z
    Z(:,i)=Z0(:,i)./norm(Z0(:,i));
end

for L=1:length(lambda)
    %% ==================================== step1.Train ===========================================
    [D,~,~,~,~]=KCD_Newton(Y,lambda(L),atoms,iter,exit_tol);
    
    %% ==================================== step2.Test ===========================================
    %% ===========================step2.feature space =======================
    KDD=kernel_rbf(D,D);
    KZD=kernel_rbf(Z,D);
    
    KDD_rowNorms=zeros(atoms,1);
    for i=1:atoms
        KDD_rowNorms(i)=norm(KDD(i,:),2);
    end
    
    %% KCD
    Z_KCD=[];
    sparsity=zeros(1,columns_z);
    for c=1:columns_z
        KzD=KZD(c,:);
        [w_KCD,~]=KCD(atoms,KzD,KDD,lambda(L),iter,exit_tol);
        sparsity(c)=sum(w_KCD~=0);
        [z_KCD,~]=y_KGD(D,KDD,w_KCD,iter,exit_tol);
        Z_KCD=[Z_KCD z_KCD];
    end
    nnz_KCD(L)=sum(sparsity);
    CR_KCD(L)=nY/nnz_KCD(L);
    LOSS_KCD(L)=norm(Z-Z_KCD,'fro')/norm(Z,'fro');
    
    
    %% FKCD
    Z_FKCD=[];
    sparsityF=zeros(1,columns_z);
    for c=1:columns_z
        KzD=KZD(c,:);
        [w_FKCD,~]=KCD_ffast(atoms,KzD,KDD,KDD_rowNorms,lambda(L),iter,exit_tol);
        sparsityF(c)=sum(w_FKCD~=0);
        [z_FKCD,~]=y_KGD(D,KDD,w_FKCD,iter,exit_tol);
        Z_FKCD=[Z_FKCD z_FKCD];
    end
    nnz_FKCD(L)=sum(sparsityF);
    CR_FKCD(L)=nY/nnz_FKCD(L);
    LOSS_FKCD(L)=norm(Z-Z_FKCD,'fro')/norm(Z,'fro');
    
    %% PAM_2016
    W_KPAM=KPAM(Z,KZD,KDD,atoms,iter,exit_tol,sparsity);   % KPAM��������������W
    Z_KPAM1=[];
    for j=1:columns_z
        w=W_KPAM(:,j);
        [z,~]=y_KGD(D,KDD,w,iter,exit_tol);
        Z_KPAM1=[Z_KPAM1 z];
    end
    LOSS_KPAM(L)=norm(Z-Z_KPAM1,'fro')/norm(Z,'fro');
    
    %% KOMP
    W_KOMP=KOMP2(Z,KDD,KZD,atoms,sparsity);
    Z_KOMP=[];
    for j=1:columns_z
        w=W_KOMP(:,j);
        [z,~]=y_KGD(D,KDD,w,iter,exit_tol);
        Z_KOMP=[Z_KOMP z];
    end
    LOSS_KOMP(L)=norm(Z-Z_KOMP,'fro')/norm(Z,'fro');
    
    %% KSR_norm21
    W_Knorm21=Knorm21(Z,KDD,KZD,atoms,lambda(L),iter,exit_tol);
    %------------------------
    for c=1:columns_z
        w_Knorm21=W_Knorm21(:,c);
        w_abs21=abs(w_Knorm21);
        [~, ind] = sort(w_abs21, 'descend');
        topSInd = ind(1:sparsity(c));
        result = zeros(atoms,1);
        result(topSInd) = w_Knorm21(topSInd);
        W_Knorm21(:,c)=result;
    end
    %-------------------------------------------------
    Z_Knorm21=[];
    for j=1:columns_z
        w=W_Knorm21(:,j);
        [z,~]=y_KGD(D,KDD,w,iter,exit_tol);
        Z_Knorm21=[Z_Knorm21 z];
    end
    nnz_Knorm21(L)=nnz(W_Knorm21);
    CR_Knorm21(L)=nY/nnz_Knorm21(L);
    LOSS_Knorm21(L)=norm(Z-Z_Knorm21,'fro')/norm(Z,'fro');
    %-------------------------------------------------
    
    
    %% ==========================step2.orginal space ========================
    %% CD
    W_CD=[];
    for c=1:columns_z
        z=Z(:,c);
        w_CD=CD(atoms,z,D,lambda(L),iter,exit_tol);
        %------------------------
        w_CDabs=abs(w_CD);
        [~, ind] = sort(w_CDabs, 'descend');
        topSInd = ind(1:sparsity(c));
        result = zeros(atoms,1);
        result(topSInd) = w_CD(topSInd);
        w_CD=result;
        %------------------------
        W_CD=[W_CD w_CD];
    end
    nnz_CD(L)=nnz(W_CD);
    CR_CD(L)=nY/nnz_CD(L);
    loss_CD(L)=norm(Z-D*W_CD,'fro')/norm(Z,'fro');
end

%% 
[CR_KCD2, I_KCD] = sort(CR_KCD);
LOSS_KCD2 = LOSS_KCD(I_KCD);

[CR_FKCD2, I_FKCD] = sort(CR_FKCD);
LOSS_FKCD2 = LOSS_FKCD(I_FKCD);

LOSS_KPAM2 = LOSS_KPAM(I_KCD);

LOSS_KOMP2 = LOSS_KOMP(I_KCD);

[CR_Knorm212, I_Knorm21] = sort(CR_Knorm21);
LOSS_Knorm212 = LOSS_Knorm21(I_Knorm21);

[CR_CD2, I_CD] = sort(CR_CD);
loss_CD2 = loss_CD(I_CD);

figure(1);
plot(CR_KCD2,LOSS_KCD2, 'LineWidth', 2); hold on;
plot(CR_FKCD2,LOSS_FKCD2, 'LineWidth', 2); hold on;
plot(CR_KCD2,LOSS_KPAM2, 'LineWidth', 2); hold on;
plot(CR_KCD2,LOSS_KOMP2, 'LineWidth', 2); hold on;
plot(CR_Knorm212,LOSS_Knorm212, 'LineWidth', 2); hold on;
plot(CR_CD2,loss_CD2, 'LineWidth', 2); 
xlabel('CR','FontSize', 14);
ylabel('NRMSE','FontSize', 14);
legend('KCD','FKCD','LPM','KOMP','KSR-L_{2,1}','CD')
title('Seattle','FontSize', 14)
grid on; 

figure(2);
plot(CR_KCD2,LOSS_KCD2,'-o', 'LineWidth', 2); hold on;
plot(CR_FKCD2,LOSS_FKCD2,'--x', 'LineWidth', 2); hold on;
plot(CR_KCD2,LOSS_KPAM2,'-d', 'LineWidth', 2); hold on;
plot(CR_KCD2,LOSS_KOMP2,'-p', 'LineWidth', 2); hold on;
plot(CR_Knorm212,LOSS_Knorm212,'-^', 'LineWidth', 2); hold on;
plot(CR_CD2,loss_CD2,'-s', 'LineWidth', 2); 
xlabel('CR','FontSize', 14);
ylabel('NRMSE','FontSize', 14);
legend('KCD','FKCD','LPM','KOMP','KSR-L_{2,1}','CD')
title('Seattle','FontSize', 14)
grid on; 