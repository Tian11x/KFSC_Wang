function [D,W,errorW,errorD,Object]=KCD_Newton(Y,lambda,atoms,iter,exit_tol)

%% Parameter initialization
[rows_y,columns_y]=size(Y);
sigma=1;

%% Dictionary matrix initialization
D0=rand(rows_y,atoms);
D=zeros(rows_y,atoms);
for i=1:atoms
    D(:,i)=D0(:,i)./norm(D0(:,i),2);
end
KDD=kernel_rbf(D,D);
KYD=kernel_rbf(Y,D);

%% =======================phi(Y)=phi(D)W=========================
W=zeros(atoms,columns_y);
for h=1:iter
    %% Sparse coding
    W_old=W;
    for c=1:columns_y
        KyD=KYD(c,:);
        for i=1:atoms
            z=KyD(i)-KDD(i,:)*W(:,c)+KDD(i,i)*W(i,c);
            if z>lambda
                W(i,c) = z-lambda;
            elseif z<-lambda
                W(i,c) = z+lambda;
            else
                W(i,c) = 0;
            end
        end
    end
    
    %% Dictionary Learning
    D_old=D;
    Q1=W'.*KYD;
    Gamma1=diag(sum(Q1,1));
    Q2=W*W'.*KDD;
    Gamma2=diag(sum(Q2,1));
    GD=(1/sigma^2)*(D*Gamma1-Y*Q1+D*Q2-D*Gamma2); 
    t=1.1*norm((1/sigma^2)*(Gamma1+Q2-Gamma2),2);
    D=D-GD/t;
    %---------------------
    for t=1:atoms
        D(:,t)=D(:,t)./norm(D(:,t),2);
    end
    %---------------------
    KYD=kernel_rbf(Y,D);
    KDD=kernel_rbf(D,D);
    
    %% Stopping condition
    errorD(h)=norm(D-D_old,'fro')/norm(D_old,'fro');
    errorW(h)=norm(W-W_old,'fro')/norm(W_old,'fro');
%     Object(h)=columns_y-trace(2*KYD*W)+trace(W'*KDD*W);
%     if errorD(h) < exit_tol
% %     if h>1 && Object(h)-Object(h-1) < exit_tol
%         fprintf('KCD_Newton reached exit tolerance at iter %d\n',h);
%         break
%     end
end
end
