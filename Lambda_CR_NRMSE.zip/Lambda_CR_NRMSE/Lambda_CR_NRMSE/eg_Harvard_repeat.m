% KCD��ѹ���ʺ;���ֱ����lambdaӰ��
% �����㷨������޹أ�ѹ������KCD��

% �ص㣺KCDѹ���ʵ����Ȳ���̫ϸ��̫ϸ������״�����ÿ�

% profile on; % ��ʼ����  
% % ��Ĵ����  
% profile off; % ֹͣ����  
% profile viewer; % �򿪷�������Ĳ鿴��

% f = @(x) x.^2; % ����һ����������  
% avgTime = timeit(f, 1e6); % ��������ִ�� 1e6 �ε�ƽ��ʱ��

clear;clc;

%% Parameter initialization
exit_tol=1e-4;
prox=1e-3;
iter=200;
sigma=1.5;
% lambda=0.002:0.002:0.1;  % 0.001��0.005��0.01��0.05��0.1��0.5��1
lambda=[0.001, 0.005, 0.01:0.01:0.1];

load('D:\Dataset\��ʦ��\Harvard226\Harvard.mat')
Q=data;

%% Train data --Y
Y0 = squeeze(Q(:, :, 1));
[rows_y,columns_y]=size(Y0);
Y=zeros(rows_y,columns_y);
for i=1:columns_y
    Y(:,i)=Y0(:,i)./norm(Y0(:,i));
end

atoms=rows_y;
nY=numel(Y);

%% Test data --Z
Z0 = squeeze(Q(:, :, 2));
[rows_z,columns_z]=size(Z0);
Z=zeros(rows_z,columns_z);
for i=1:columns_z
    Z(:,i)=Z0(:,i)./norm(Z0(:,i));
end

%% ��ʼ��
REPEAT=5;

TIME_KCD=zeros(1,length(lambda));
OBJECT_KCD=zeros(1,length(lambda));
NRMSE_KCD=zeros(1,length(lambda));
NMAE_KCD=zeros(1,length(lambda));
CR_KCD=zeros(1,length(lambda));

TIME_FKCD=zeros(1,length(lambda));
OBJECT_FKCD=zeros(1,length(lambda));
NRMSE_FKCD=zeros(1,length(lambda));
NMAE_FKCD=zeros(1,length(lambda));
CR_FKCD=zeros(1,length(lambda));

TIME_KPAM=zeros(1,length(lambda));
OBJECT_KPAM=zeros(1,length(lambda));
NRMSE_KPAM=zeros(1,length(lambda));
NMAE_KPAM=zeros(1,length(lambda));

TIME_Knorm21=zeros(1,length(lambda));
OBJECT_Knorm21=zeros(1,length(lambda));
NRMSE_Knorm21=zeros(1,length(lambda));
NMAE_Knorm21=zeros(1,length(lambda));

TIME_Kfro=zeros(1,length(lambda));
OBJECT_Kfro=zeros(1,length(lambda));
NRMSE_Kfro=zeros(1,length(lambda));
NMAE_Kfro=zeros(1,length(lambda));

TIME_CD=zeros(1,length(lambda));
OBJECT_CD=zeros(1,length(lambda));
NRMSE_CD=zeros(1,length(lambda));
NMAE_CD=zeros(1,length(lambda));

for L=1:length(lambda)
    %% ==================================== step1.Train ===========================================
    D=KCD_Newton_sigma(Y,lambda(L),sigma,atoms,iter,exit_tol);
    
    %% ==================================== step2.Test ===========================================
    %% ===========================step2.feature space =======================
    KDD=kernel_rbf_sigma(sigma,D,D);
    KZD=kernel_rbf_sigma(sigma,Z,D);
    
    KDD_rowNorms=zeros(atoms,1);
    for i=1:atoms
        KDD_rowNorms(i)=norm(KDD(i,:),2);
    end
    
    %% KCD_z
    % ��ʼ��
    sparsity=zeros(REPEAT,columns_z);
    W_KCD=zeros(atoms,columns_z);
    time_KCD=zeros(REPEAT,1);
    Z_KCD=zeros(rows_z,columns_z);
    object_KCD=zeros(REPEAT,1);
    nrmse_KCD=zeros(REPEAT,1);
    nmae_KCD=zeros(REPEAT,1);
    
    for repeat=1:REPEAT
        t_KCD=tic;
        for c=1:columns_z
            KzD=KZD(c,:);
            [W_KCD(:,c),~]=KCD(atoms,KzD,KDD,lambda(L),iter,exit_tol);
        end
        time_KCD(repeat)=toc(t_KCD);
        sparsity(repeat,:)=sum(W_KCD~=0,1);
        
        for c=1:columns_z
            w_KCD=W_KCD(:,c);
            Z_KCD(:,c)=y_KGD(D,KDD,w_KCD,sigma,iter,exit_tol);
        end
        object_KCD(repeat)=columns_z-trace(2*KZD*W_KCD)+trace(W_KCD'*KDD*W_KCD);
        nrmse_KCD(repeat)=norm(Z-Z_KCD,'fro')/norm(Z,'fro');
        
        ZZ_KCD=Z-Z_KCD;
        nmae_KCD(repeat)=sum(abs(ZZ_KCD(:)))/sum(abs(Z(:)));
    end
    TIME_KCD(L)=mean(time_KCD);
    SPARSITY=fix(mean(sparsity));
    OBJECT_KCD(L)=mean(object_KCD);
    NRMSE_KCD(L)=mean(nrmse_KCD);
    NMAE_KCD(L)=mean(nmae_KCD);
    
    nnz_KCD=sum(SPARSITY);
    CR_KCD(L)=nY/nnz_KCD;
             
    %% FKCD
    % ��ʼ��
    sparsityF=zeros(REPEAT,columns_z);
    W_FKCD=zeros(atoms,columns_z);
    time_FKCD=zeros(REPEAT,1);
    Z_FKCD=zeros(rows_z,columns_z);
    object_FKCD=zeros(REPEAT,1);
    nrmse_FKCD=zeros(REPEAT,1);
    nmae_FKCD=zeros(REPEAT,1);
    
    for repeat=1:REPEAT
        t_FKCD=tic;
        for c=1:columns_z
            KzD=KZD(c,:);
            [W_FKCD(:,c),~]=KCD_fast(atoms,KzD,KDD,KDD_rowNorms,lambda(L),iter,exit_tol);
        end
        time_FKCD(repeat)=toc(t_FKCD);
        sparsityF(repeat,:)=sum(W_FKCD~=0,1);

        for c=1:columns_z
            w_FKCD=W_FKCD(:,c);
            Z_FKCD(:,c)=y_KGD(D,KDD,w_FKCD,sigma,iter,exit_tol);
        end
        object_FKCD(repeat)=columns_z-trace(2*KZD*W_FKCD)+trace(W_FKCD'*KDD*W_FKCD);
        nrmse_FKCD(repeat)=norm(Z-Z_FKCD,'fro')/norm(Z,'fro');
        
        ZZ_FKCD=Z-Z_FKCD;
        nmae_FKCD(repeat)=sum(abs(ZZ_FKCD(:)))/sum(abs(Z(:)));
    end
    TIME_FKCD(L)=mean(time_FKCD);
    SPARSITYF=fix(mean(sparsityF));
    OBJECT_FKCD(L)=mean(object_FKCD);
    NRMSE_FKCD(L)=mean(nrmse_FKCD);
    NMAE_FKCD(L)=mean(nmae_FKCD);
    
    nnz_FKCD=sum(SPARSITYF);
    CR_FKCD(L)=nY/nnz_FKCD;
       
    %% PAM_2016
    sigma_KPAM=sigma;
    KDD_KPAM=kernel_rbf_sigma(sigma_KPAM,D,D);
    KZD_KPAM=kernel_rbf_sigma(sigma_KPAM,Z,D);
    % ��ʼ��
    time_KPAM=zeros(REPEAT,1);
    Z_KPAM=zeros(rows_z,columns_z);
    object_KPAM=zeros(REPEAT,1);
    nrmse_KPAM=zeros(REPEAT,1);
    nmae_KPAM=zeros(REPEAT,1);
    
    for repeat=1:REPEAT
        t_KPAM=tic;
        W_KPAM=KPAM(Z,KZD_KPAM,KDD_KPAM,atoms,iter,exit_tol,SPARSITY);
        time_KPAM(repeat)=toc(t_KPAM);
        object_KPAM(repeat)=columns_z-trace(2*KZD_KPAM*W_KPAM)+trace(W_KPAM'*KDD_KPAM*W_KPAM);
        
        for c=1:columns_z
            w=W_KPAM(:,c);
            Z_KPAM(:,c)=y_KGD(D,KDD,w,sigma,iter,exit_tol);
        end
        nrmse_KPAM(repeat)=norm(Z-Z_KPAM,'fro')/norm(Z,'fro');
        
        ZZ_KPAM=Z-Z_KPAM;
        nmae_KPAM(repeat)=sum(abs(ZZ_KPAM(:)))/sum(abs(Z(:)));
    end
    TIME_KPAM(L)=mean(time_KPAM);
    OBJECT_KPAM(L)=mean(object_KPAM);
    NRMSE_KPAM(L)=mean(nrmse_KPAM);
    NMAE_KPAM(L)=mean(nmae_KPAM);
    
    %% KOMP
%     t_KOMP=tic;
%     W_KOMP=KOMP2(Z,KDD,KZD,atoms,sparsity);
%     T_KOMP(L)=toc(t_KOMP);
%     Object_KOMP(L)=columns_z-trace(2*KZD*W_KOMP)+trace(W_KOMP'*KDD*W_KOMP);
%     Z_KOMP=[];
%     for j=1:columns_z
%         w=W_KOMP(:,j);
%         z_KOMP=y_KGD(D,KDD,w,sigma,iter,exit_tol);
%         Z_KOMP=[Z_KOMP z_KOMP];
%     end
%     LOSS_KOMP(L)=norm(Z-Z_KOMP,'fro')/norm(Z,'fro');
%     
%     ZZ_KOMP=Z-Z_KOMP;
%     logical_KOMP = abs(ZZ_KOMP) < prox;  
%     N_KOMP(L)=sum(logical_KOMP(:));
    
    %% KSR_norm21
    % ��ʼ��
    time_Knorm21=zeros(REPEAT,1);
    Z_Knorm21=zeros(rows_z,columns_z);
    object_Knorm21=zeros(REPEAT,1);
    nrmse_Knorm21=zeros(REPEAT,1);
    nmae_Knorm21=zeros(REPEAT,1);
    
    for repeat=1:REPEAT
        t_Knorm21=tic;
        W_Knorm21=Knorm21(Z,KDD,KZD,atoms,lambda(L),iter,exit_tol,SPARSITY);
        time_Knorm21(repeat)=toc(t_Knorm21);
        object_Knorm21(repeat)=columns_z-trace(2*KZD* W_Knorm21)+trace(W_Knorm21'*KDD* W_Knorm21);
        for c=1:columns_z
            w=W_Knorm21(:,c);
            Z_Knorm21(:,c)=y_KGD(D,KDD,w,sigma,iter,exit_tol);
        end
        nrmse_Knorm21(repeat)=norm(Z-Z_Knorm21,'fro')/norm(Z,'fro');
        
        ZZ_Knorm21=Z-Z_Knorm21;
        nmae_Knorm21(repeat)=sum(abs(ZZ_Knorm21(:)))/sum(abs(Z(:)));
    end
    TIME_Knorm21(L)=mean(time_Knorm21);
    OBJECT_Knorm21(L)=mean(object_Knorm21);
    NRMSE_Knorm21(L)=mean(nrmse_Knorm21);
    NMAE_Knorm21(L)=mean(nmae_Knorm21);

    %% KSR_norm_fro
    % ��ʼ��
    time_Kfro=zeros(REPEAT,1);
    Z_Kfro=zeros(rows_z,columns_z);
    object_Kfro=zeros(REPEAT,1);
    nrmse_Kfro=zeros(REPEAT,1);
    nmae_Kfro=zeros(REPEAT,1);
    
    for repeat=1:REPEAT
        t_Kfro=tic;
        W_Kfro=Kfro(Z,KDD,KZD,atoms,lambda(L),iter,exit_tol,SPARSITY);
        time_Kfro(repeat)=toc(t_Kfro);
        object_Kfro(repeat)=columns_z-trace(2*KZD* W_Kfro)+trace( W_Kfro'*KDD* W_Kfro);
        for c=1:columns_z
            w=W_Kfro(:,c);
            Z_Kfro(:,c)=y_KGD(D,KDD,w,sigma,iter,exit_tol);
        end
        nrmse_Kfro(repeat)=norm(Z-Z_Kfro,'fro')/norm(Z,'fro');
        
        ZZ_Kfro=Z-Z_Kfro;
        nmae_Kfro(repeat)=sum(abs(ZZ_Kfro(:)))/sum(abs(Z(:)));
    end
    TIME_Kfro(L)=mean(time_Kfro);
    OBJECT_Kfro(L)=mean(object_Kfro);
    NRMSE_Kfro(L)=mean(nrmse_Kfro);
    NMAE_Kfro(L)=mean(nmae_Kfro);
    
    %% ==========================step2.orginal space ========================
    %% CD
    % ��ʼ��
    W_CD=zeros(atoms,columns_z);
    time_CD=zeros(REPEAT,1);
    object_CD=zeros(REPEAT,1);
    nrmse_CD=zeros(REPEAT,1);
    nmae_CD=zeros(REPEAT,1);
    
    for repeat=1:REPEAT
        t_CD=tic;
        for c=1:columns_z
            z=Z(:,c);
            W_CD(:,c)=CD(atoms,z,D,lambda(L),iter,exit_tol,SPARSITY(c));
        end
        time_CD(repeat)=toc(t_CD);
        
        nrmse_CD(repeat)=norm(Z-D*W_CD,'fro')/norm(Z,'fro');
        object_CD(repeat)=columns_z-trace(2*KZD*W_CD)+trace( W_CD'*KDD*W_CD);
        
        ZZ_CD=Z-D*W_CD;
        nmae_CD(repeat)=sum(abs(ZZ_CD(:)))/sum(abs(Z(:)));
    end
    TIME_CD(L)=mean(time_CD);
    OBJECT_CD(L)=mean(object_CD);
    NRMSE_CD(L)=mean(nrmse_CD);
    NMAE_CD(L)=mean(nmae_CD);
end

% Min_CD=loss_CD.*T_CD;
% Min_FKCD=LOSS_FKCD.*T_FKCD;
% Min_KCD=LOSS_KCD.*T_KCD;
% Min_Kfro=LOSS_Kfro.*T_Kfro;
% Min_Knorm21=LOSS_Knorm21.*T_Knorm21;
% Min_KOMP=LOSS_KOMP.*T_KOMP;
% Min_KPAM=LOSS_KPAM.*T_KPAM;
% 
% Max_CD=N_CD./Min_CD;
% Max_FKCD=N_FKCD./Min_FKCD;
% Max_KCD=N_KCD./Min_KCD;
% Max_Kfro=N_Kfro./Min_Kfro;
% Max_Knorm21=N_Knorm21./Min_Knorm21;
% Max_KOMP=N_KOMP./Min_KOMP;
% Max_KPAM=N_KPAM./Min_KPAM;

% figure(1);
% plot(lambda,Object_KCD,'-o', 'LineWidth', 2); hold on;
% plot(lambda,Object_FKCD,'--x', 'LineWidth', 2); hold on;
% plot(lambda,Object_KPAM,'-d', 'LineWidth', 2); hold on;
% plot(lambda,Object_KOMP,'-p', 'LineWidth', 2); hold on;
% plot(lambda,Object_Knorm21,'-^', 'LineWidth', 2); hold on;
% plot(lambda,Object_Kfro,'-^', 'LineWidth', 2); hold on;
% plot(lambda,Object_CD,'-s', 'LineWidth', 2); 
% xlabel('\lambda');
% ylabel('||��(Y)-��(X)W||_{F}^2');
% legend('KCD','FKCD','LPM','KOMP','KSR-L_{2,1}','KFMC','CD')
% title('Harvard')
% grid on; 

figure(2);
plot(lambda,NRMSE_KCD,'-o', 'LineWidth', 2); hold on;
plot(lambda,LOSS_FKCD,'--x', 'LineWidth', 2); hold on;
plot(lambda,LOSS_KPAM,'-d', 'LineWidth', 2); hold on;
plot(lambda,LOSS_Knorm21,'-^', 'LineWidth', 2); hold on;
plot(lambda,LOSS_Kfro,'-^', 'LineWidth', 2); hold on;
plot(lambda,loss_CD,'-s', 'LineWidth', 2); 
xlabel('\lambda');
ylabel('NRMSE');
legend('KCD','FKCD','LPM','KSR-L_{2,1}','KFMC','CD')
title('Harvard')
grid on; 

% ����ֱ��ͼ 
figure(3);
N_recover= [N_KCD',N_FKCD',N_KPAM',N_Knorm21',N_Kfro',N_CD'];
h=bar(N_recover); 
% set(gca, 'XTickLabel', num2str(lambda));
set(gca, 'XTickLabel', {'0.001', '0.005', '0.01', '0.02', '0.03', '0.04', '0.05', '0.06','0.07','0.08','0.09', '0.1'});
xlabel('\lambda','FontSize', 16);
ylabel('No. of correctly recovered','FontSize', 16);
legend('KCD','FKCD','LPM','KSR-L_{2,1}','KFMC','CD')

% ����ֱ��ͼ 
figure(4);
speed= [T_KCD',T_FKCD',T_KPAM',T_Knorm21',T_Kfro',T_CD'];
h=bar(speed);
set(gca, 'XTickLabel', {'0.001', '0.005', '0.01', '0.02', '0.03', '0.04', '0.05', '0.06','0.07','0.08','0.09', '0.1'});
xlabel('\lambda','FontSize', 16);
ylabel('Time (s)','FontSize', 16);
legend('KCD','FKCD','LPM','KSR-L_{2,1}','KFMC','CD')

% figure(5);
% plot(lambda,Max_KCD,'-o', 'LineWidth', 2); hold on;
% plot(lambda,Max_FKCD,'--x', 'LineWidth', 2); hold on;
% plot(lambda,Max_KPAM,'-d', 'LineWidth', 2); hold on;
% plot(lambda,Max_KOMP,'-p', 'LineWidth', 2); hold on;
% plot(lambda,Max_Knorm21,'-^', 'LineWidth', 2); hold on;
% plot(lambda,Max_Kfro,'-^', 'LineWidth', 2); hold on;
% plot(lambda,Max_CD,'-s', 'LineWidth', 2); 
% xlabel('\lambda');
% ylabel('The larger, the better');
% legend('KCD','FKCD','LPM','KOMP','KSR-L_{2,1}','KFMC','CD')
% title('Harvard')
% grid on; 



%% 
% [CR_KCD2, I_KCD] = sort(CR_KCD);
% LOSS_KCD2 = LOSS_KCD(I_KCD);
% 
% [CR_FKCD2, I_FKCD] = sort(CR_FKCD);
% LOSS_FKCD2 = LOSS_FKCD(I_FKCD);
% 
% LOSS_KPAM2 = LOSS_KPAM(I_KCD);
% 
% LOSS_KOMP2 = LOSS_KOMP(I_KCD);
% 
% [CR_Knorm212, I_Knorm21] = sort(CR_Knorm21);
% LOSS_Knorm212 = LOSS_Knorm21(I_Knorm21);
% 
% [CR_CD2, I_CD] = sort(CR_CD);
% loss_CD2 = loss_CD(I_CD);
% 
% figure(10);
% plot(CR_KCD2,LOSS_KCD2,'-o', 'LineWidth', 2); hold on;
% plot(CR_FKCD2,LOSS_FKCD2,'-o', 'LineWidth', 2); hold on;
% plot(CR_KCD2,LOSS_KPAM2, '-o','LineWidth', 2); hold on;
% plot(CR_KCD2,LOSS_KOMP2,'-o', 'LineWidth', 2); hold on;
% plot(CR_Knorm212,LOSS_Knorm212,'-o', 'LineWidth', 2); hold on;
% plot(CR_CD2,loss_CD2,'-o', 'LineWidth', 2); 
% xlabel('CR','FontSize', 14);
% ylabel('NRMSE','FontSize', 14);
% legend('KCD','FKCD','LPM','KOMP','KSR-L_{2,1}','CD')
% title('Harvard','FontSize', 14)
% grid on; 


