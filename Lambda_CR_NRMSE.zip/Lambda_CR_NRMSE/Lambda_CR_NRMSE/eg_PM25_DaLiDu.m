% ���ݼ�ȫ������

clear;clc;

%% Parameter initialization
exit_tol=1e-4;
prox=1e-3;
iter=20;
sigma=1.5;
% lambda=0.002:0.002:0.1;  % 0.001��0.005��0.01��0.05��0.1��0.5��1
lambda=[0.001, 0.003, 0.005, 0.007, 0.01, 0.03, 0.05, 0.07, 0.1];

load('D:\Dataset\��ʦ��\PM2.5\PM25_tensor.mat');
tensor=double(Y_source);
[s1, s2, s3] = size(tensor);

%% Train data --Y
Y0=[];
for i=1:s2/2
    slice1=tensor(:, i, :);
    slice11=reshape(slice1, s1, s3);
    Y0 =[Y0 slice11];
end
[rows_y,columns_y]=size(Y0);
Y=zeros(rows_y,columns_y);
for i=1:columns_y
    Y(:,i)=Y0(:,i)./norm(Y0(:,i));
end

atoms=rows_y;
nY=numel(Y);

%% Test data --Z
Z0=[];
for i=(s2/2+1):s2
    slice2=tensor(:, i, :);
    slice22=reshape(slice2, s1, s3);
    Z0 =[Z0 slice22];
end

[rows_z,columns_z]=size(Z0);
Z=zeros(rows_z,columns_z);
for i=1:columns_z
    Z(:,i)=Z0(:,i)./norm(Z0(:,i));
end

for L=1:length(lambda)
    %% ==================================== step1.Train ===========================================
    D=KCD_Newton_sigma(Y,lambda(L),sigma,atoms,iter,exit_tol);
    
    %% ==================================== step2.Test ===========================================
    %% ===========================step2.feature space =======================
    KDD=kernel_rbf_sigma(sigma,D,D);
    KZD=kernel_rbf_sigma(sigma,Z,D);
    
    KDD_rowNorms=zeros(atoms,1);
    for i=1:atoms
        KDD_rowNorms(i)=norm(KDD(i,:),2);
    end
    
    %% KCD_z
    W_KCD=[];
    t_KCD=tic;
    for c=1:columns_z
        KzD=KZD(c,:);
        [w_KCD,~]=KCD(atoms,KzD,KDD,lambda(L),iter,exit_tol);
        W_KCD=[W_KCD,w_KCD];
    end
    T_KCD(L)=toc(t_KCD);
    sparsity=sum(W_KCD~=0,1);
    
    Z_KCD=[];
    for c=1:columns_z
        w_KCD=W_KCD(:,c);
        z_KCD=y_KGD(D,KDD,w_KCD,sigma,iter,exit_tol);
        Z_KCD=[Z_KCD z_KCD];
    end
    Object_KCD(L)=columns_z-trace(2*KZD*W_KCD)+trace(W_KCD'*KDD*W_KCD);
    LOSS_KCD(L)=norm(Z-Z_KCD,'fro')/norm(Z,'fro'); 
    
    ZZ_KCD=Z-Z_KCD;
    logical_KCD = abs(ZZ_KCD) < prox;  
    N_KCD(L)=sum(logical_KCD(:)); 
    
    nnz_KCD(L)=sum(sparsity);
    CR_KCD(L)=nY/nnz_KCD(L);
             
    %% FKCD
    W_FKCD=[];
    t_FKCD=tic;
    for c=1:columns_z
        KzD=KZD(c,:);
        [w_FKCD,~]=KCD_fast(atoms,KzD,KDD,KDD_rowNorms,lambda(L),iter,exit_tol);
        W_FKCD=[W_FKCD w_FKCD];
    end
    T_FKCD(L)=toc(t_FKCD);
    sparsityF=sum(W_FKCD~=0,1);
    Z_FKCD=[];
    for c=1:columns_z
        w_FKCD=W_FKCD(:,c);
        z_FKCD=y_KGD(D,KDD,w_FKCD,sigma,iter,exit_tol);
        Z_FKCD=[Z_FKCD z_FKCD];
    end
    Object_FKCD(L)=columns_z-trace(2*KZD*W_FKCD)+trace(W_FKCD'*KDD*W_FKCD);
    LOSS_FKCD(L)=norm(Z-Z_FKCD,'fro')/norm(Z,'fro');
    
    ZZ_FKCD=Z-Z_FKCD;
    logical_FKCD = abs(ZZ_FKCD) < prox;  
    N_FKCD(L)=sum(logical_FKCD(:)); 
    
    nnz_FKCD(L)=sum(sparsityF);
    CR_FKCD(L)=nY/nnz_FKCD(L);
       
    %% PAM_2016
    sigma_KPAM=5;
    KDD_KPAM=kernel_rbf_sigma(sigma_KPAM,D,D);
    KZD_KPAM=kernel_rbf_sigma(sigma_KPAM,Z,D);
    t_KPAM=tic;
    W_KPAM=KPAM(Z,KZD_KPAM,KDD_KPAM,atoms,iter,exit_tol,sparsity);  
    T_KPAM(L)=toc(t_KPAM);
    Object_KPAM(L)=columns_z-trace(2*KZD_KPAM*W_KPAM)+trace(W_KPAM'*KDD_KPAM*W_KPAM);
    Z_KPAM=[];
    for j=1:columns_z
        w=W_KPAM(:,j);
        z_KPAM=y_KGD(D,KDD,w,sigma,iter,exit_tol);
        Z_KPAM=[Z_KPAM z_KPAM];
    end
    LOSS_KPAM(L)=norm(Z-Z_KPAM,'fro')/norm(Z,'fro');
    
    ZZ_KPAM=Z-Z_KPAM;
    logical_KPAM = abs(ZZ_KPAM) < prox;  
    N_KPAM(L)=sum(logical_KPAM(:)); 
    
    %% KOMP
    t_KOMP=tic;
    W_KOMP=KOMP2(Z,KDD,KZD,atoms,sparsity);
    T_KOMP(L)=toc(t_KOMP);
    Object_KOMP(L)=columns_z-trace(2*KZD*W_KOMP)+trace(W_KOMP'*KDD*W_KOMP);
    Z_KOMP=[];
    for j=1:columns_z
        w=W_KOMP(:,j);
        z_KOMP=y_KGD(D,KDD,w,sigma,iter,exit_tol);
        Z_KOMP=[Z_KOMP z_KOMP];
    end
    LOSS_KOMP(L)=norm(Z-Z_KOMP,'fro')/norm(Z,'fro');
    
    ZZ_KOMP=Z-Z_KOMP;
    logical_KOMP = abs(ZZ_KOMP) < prox;  
    N_KOMP(L)=sum(logical_KOMP(:));
    
    %% KSR_norm21
    t_Knorm21=tic;
    W_Knorm21=Knorm21(Z,KDD,KZD,atoms,lambda(L),iter,exit_tol,sparsity);
    T_Knorm21(L)=toc(t_Knorm21);
    Object_Knorm21(L)=columns_z-trace(2*KZD* W_Knorm21)+trace(W_Knorm21'*KDD* W_Knorm21);
    Z_Knorm21=[];
    for j=1:columns_z
        w=W_Knorm21(:,j);
        z_Knorm21=y_KGD(D,KDD,w,sigma,iter,exit_tol);
        Z_Knorm21=[Z_Knorm21 z_Knorm21];
    end
    LOSS_Knorm21(L)=norm(Z-Z_Knorm21,'fro')/norm(Z,'fro');
    
    ZZ_Knorm21=Z-Z_Knorm21;
    logical_Knorm21 = abs(ZZ_Knorm21) < prox;  
    N_Knorm21(L)=sum(logical_Knorm21(:));

    %% KSR_norm_fro
    t_Kfro=tic;
    W_Kfro=Kfro(Z,KDD,KZD,atoms,lambda(L),iter,exit_tol,sparsity);
    T_Kfro(L)=toc(t_Kfro);
    Object_Kfro(L)=columns_z-trace(2*KZD* W_Kfro)+trace( W_Kfro'*KDD* W_Kfro);
    Z_Kfro=[];
    for j=1:columns_z
        w=W_Kfro(:,j);
        z_Kfro=y_KGD(D,KDD,w,sigma,iter,exit_tol);
        Z_Kfro=[Z_Kfro z_Kfro];
    end
    LOSS_Kfro(L)=norm(Z-Z_Kfro,'fro')/norm(Z,'fro');
    
    ZZ_Kfro=Z-Z_Kfro;
    logical_Kfro = abs(ZZ_Kfro) < prox;  
    N_Kfro(L)=sum(logical_Kfro(:));
    
    %% ==========================step2.orginal space ========================
    %% CD
    W_CD=[];
    t_CD=tic;
    for c=1:columns_z
        z=Z(:,c);
        w_CD=CD(atoms,z,D,lambda(L),iter,exit_tol);
        %------------------------
        w_CDabs=abs(w_CD);
        [~, ind] = sort(w_CDabs, 'descend');
        topSInd = ind(1:sparsity(c));
        result = zeros(atoms,1);
        result(topSInd) = w_CD(topSInd);
        w_CD=result;
        %------------------------
        W_CD=[W_CD w_CD];
    end
    T_CD(L)=toc(t_CD);

    loss_CD(L)=norm(Z-D*W_CD,'fro')/norm(Z,'fro');
    Object_CD(L)=columns_z-trace(2*KZD*W_CD)+trace( W_CD'*KDD*W_CD);
    
    ZZ_CD=Z-D*W_CD;
    logical_CD = abs(ZZ_CD) < prox;  
    N_CD(L)=sum(logical_CD(:));
end

Min_CD=loss_CD.*T_CD;
Min_FKCD=LOSS_FKCD.*T_FKCD;
Min_KCD=LOSS_KCD.*T_KCD;
Min_Kfro=LOSS_Kfro.*T_Kfro;
Min_Knorm21=LOSS_Knorm21.*T_Knorm21;
Min_KOMP=LOSS_KOMP.*T_KOMP;
Min_KPAM=LOSS_KPAM.*T_KPAM;

Max_CD=N_CD./Min_CD;
Max_FKCD=N_FKCD./Min_FKCD;
Max_KCD=N_KCD./Min_KCD;
Max_Kfro=N_Kfro./Min_Kfro;
Max_Knorm21=N_Knorm21./Min_Knorm21;
Max_KOMP=N_KOMP./Min_KOMP;
Max_KPAM=N_KPAM./Min_KPAM;

figure(1);
plot(lambda,Object_KCD,'-o', 'LineWidth', 2); hold on;
plot(lambda,Object_FKCD,'--x', 'LineWidth', 2); hold on;
plot(lambda,Object_KPAM,'-d', 'LineWidth', 2); hold on;
plot(lambda,Object_KOMP,'-p', 'LineWidth', 2); hold on;
plot(lambda,Object_Knorm21,'-^', 'LineWidth', 2); hold on;
plot(lambda,Object_Kfro,'-^', 'LineWidth', 2); hold on;
plot(lambda,Object_CD,'-s', 'LineWidth', 2); 
xlabel('\lambda');
ylabel('||��(Y)-��(X)W||_{F}^2');
legend('KCD','FKCD','LPM','KOMP','KSR-L_{2,1}','KFMC','CD')
title('PM2.5')
grid on; 

figure(2);
plot(lambda,LOSS_KCD,'-o', 'LineWidth', 2); hold on;
plot(lambda,LOSS_FKCD,'--x', 'LineWidth', 2); hold on;
plot(lambda,LOSS_KPAM,'-d', 'LineWidth', 2); hold on;
plot(lambda,LOSS_KOMP,'-p', 'LineWidth', 2); hold on;
plot(lambda,LOSS_Knorm21,'-^', 'LineWidth', 2); hold on;
plot(lambda,LOSS_Kfro,'-^', 'LineWidth', 2); hold on;
plot(lambda,loss_CD,'-s', 'LineWidth', 2); 
xlabel('\lambda');
ylabel('NRMSE');
legend('KCD','FKCD','LPM','KOMP','KSR-L_{2,1}','KFMC','CD')
title('PM2.5')
grid on; 

% ����ֱ��ͼ 
figure(3);
N_recover= [N_KCD',N_FKCD',N_KPAM',N_KOMP',N_Knorm21',N_Kfro',N_CD'];
h=bar(N_recover);
set(gca, 'XTickLabel', {'0.001', '0.003', '0.005', '0.007', '0.01', '0.03', '0.05', '0.07', '0.1'});
xlabel('\lambda','FontSize', 16);
ylabel('No. of correctly recovered','FontSize', 16);
legend('KCD','FKCD','LPM','KOMP','KSR-L_{2,1}','KFMC','CD')
title('PM2.5')

% ����ֱ��ͼ 
figure(4);
speed= [T_KCD',T_FKCD',T_KPAM',T_KOMP',T_Knorm21',T_Kfro',T_CD'];
h=bar(speed);
set(gca, 'XTickLabel', {'0.001', '0.003', '0.005', '0.007', '0.01', '0.03', '0.05', '0.07', '0.1'});
xlabel('\lambda','FontSize', 16);
ylabel('Time (s)','FontSize', 16);
legend('KCD','FKCD','LPM','KOMP','KSR-L_{2,1}','KFMC','CD')
title('PM2.5')

% figure(5);
% plot(lambda,Max_KCD,'-o', 'LineWidth', 2); hold on;
% plot(lambda,Max_FKCD,'--x', 'LineWidth', 2); hold on;
% plot(lambda,Max_KPAM,'-d', 'LineWidth', 2); hold on;
% plot(lambda,Max_KOMP,'-p', 'LineWidth', 2); hold on;
% plot(lambda,Max_Knorm21,'-^', 'LineWidth', 2); hold on;
% plot(lambda,Max_Kfro,'-^', 'LineWidth', 2); hold on;
% plot(lambda,Max_CD,'-s', 'LineWidth', 2); 
% xlabel('\lambda');
% ylabel('The larger, the better');
% legend('KCD','FKCD','LPM','KOMP','KSR-L_{2,1}','KFMC','CD')
% title('Traffic-Guangzhou')
% grid on; 



%% 
% [CR_KCD2, I_KCD] = sort(CR_KCD);
% LOSS_KCD2 = LOSS_KCD(I_KCD);
% 
% [CR_FKCD2, I_FKCD] = sort(CR_FKCD);
% LOSS_FKCD2 = LOSS_FKCD(I_FKCD);
% 
% LOSS_KPAM2 = LOSS_KPAM(I_KCD);
% 
% LOSS_KOMP2 = LOSS_KOMP(I_KCD);
% 
% [CR_Knorm212, I_Knorm21] = sort(CR_Knorm21);
% LOSS_Knorm212 = LOSS_Knorm21(I_Knorm21);
% 
% [CR_CD2, I_CD] = sort(CR_CD);
% loss_CD2 = loss_CD(I_CD);
% 
% figure(10);
% plot(CR_KCD2,LOSS_KCD2,'-o', 'LineWidth', 2); hold on;
% plot(CR_FKCD2,LOSS_FKCD2,'-o', 'LineWidth', 2); hold on;
% plot(CR_KCD2,LOSS_KPAM2, '-o','LineWidth', 2); hold on;
% plot(CR_KCD2,LOSS_KOMP2,'-o', 'LineWidth', 2); hold on;
% plot(CR_Knorm212,LOSS_Knorm212,'-o', 'LineWidth', 2); hold on;
% plot(CR_CD2,loss_CD2,'-o', 'LineWidth', 2); 
% xlabel('CR','FontSize', 14);
% ylabel('NRMSE','FontSize', 14);
% legend('KCD','FKCD','LPM','KOMP','KSR-L_{2,1}','CD')
% title('Harvard','FontSize', 14)
% grid on; 


