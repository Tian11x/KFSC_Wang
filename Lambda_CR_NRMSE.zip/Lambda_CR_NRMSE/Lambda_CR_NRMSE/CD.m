function w=CD(atoms,y,X,lambda,iter,exit_tol,sparsity)
XX=X'*X;
X_col_norm=diag(XX);
yX=y'*X;
% w=inv(XX+0.001*eye(p))*X'*y; 
z=zeros(atoms,1);
w=zeros(atoms,1);
for h=1:iter
    w_old = w;
    for i = 1 : atoms
        z(i)=yX(i)-XX(i,:)*w+w(i)*X_col_norm(i);
        if z(i)>lambda
            w(i) = (z(i)-lambda)/X_col_norm(i);
        elseif z(i)<-lambda
            w(i) = (z(i)+lambda)/X_col_norm(i);
        else
            w(i) = 0;
        end
    end
    %------------------------
    w_abs=abs(w);
    [~, ind] = sort(w_abs, 'descend');
    topSInd = ind(1:sparsity);
    result = zeros(atoms,1);
    result(topSInd) = w(topSInd);
    w=result;
    %------------------------
    %%  stopping criterion
    loss(h)=norm(y-X*w,'fro');
    if h>1
        error=abs(loss(h)-loss(h-1));
        Error_w = norm(w-w_old,2)/norm(w_old,2);
        if  error<exit_tol && Error_w < exit_tol
            fprintf('CD reached exit tolerance at iter %d\n',h);
            break;
        end
    end
end
end
