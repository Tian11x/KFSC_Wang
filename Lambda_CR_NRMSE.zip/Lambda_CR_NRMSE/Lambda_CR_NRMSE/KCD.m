function w=KCD(atoms,KyX,KXX,lambda,iter,exit_tol)

%% initialize
% w=inv(KXX+0.001*eye(atoms))*(KyX');  % w^{0}
w=zeros(atoms,1);

%% w
for h=1:iter;
    w_old = w;
    for i = 1 : atoms
        z=KyX(i)-KXX(i,:)*w+KXX(i,i)*w(i);
        % ��Ϊ��w=zeros(atoms,1)����if |KyX(i)|<lambda, �� w=0
        % �����������KyX����ȫ��[-lambda,lambda]֮��
        if z>lambda
            w(i) = z-lambda;
        elseif z<-lambda
            w(i) = z+lambda;
        else
            w(i) = 0;
        end
    end
    loss(h)=1-2*KyX*w+w'*KXX*w;
    
    if h>1
        error=abs(loss(h)-loss(h-1));
        Error_w = norm(w-w_old,2)/norm(w_old,2);
        if  error<exit_tol && Error_w < exit_tol
            fprintf('KCD reached exit tolerance at iter %d\n',h);
            break;
        end
    end
end

end