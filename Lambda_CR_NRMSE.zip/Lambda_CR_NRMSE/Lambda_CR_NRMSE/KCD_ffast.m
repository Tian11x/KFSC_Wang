function [w,W]=KCD_ffast(atoms,KyX,KXX,KXX_rowNorms,lambda,iter,exit_tol)

%% initialize
w=zeros(atoms,1);
z=zeros(atoms,1);
W=[];  % �鿴�������

%% Initially updated normally
for n=1:2;
    w_old=w;
    for i=1:atoms
        z(i)=KyX(i)-KXX(i,:)*w+KXX(i,i)*w(i);
        if z(i)>lambda
            w(i) = z(i)-lambda;
        elseif z(i)<-lambda
            w(i) = z(i)+lambda;
        else
            w(i) = 0;
        end
    end
    W=[W w];
end
Dw=w-w_old;
DwiNorm=norm(Dw);

%% search for the set of nonzero weights
Omega=[];
for i=1:atoms
    if i==1
        DwiNorm=sqrt(DwiNorm^2-Dw(i)^2);
    else
        DwiNorm=sqrt(DwiNorm^2-Dw(i)^2+Dw(i-1)^2);
    end
    Theta=KXX_rowNorms(i)*DwiNorm;
    z_upper=z(i)+Theta;
    z_lower=z(i)-Theta;
    if z_upper<-lambda || z_lower>lambda
        Omega=[Omega,i];  % �ض�����
    end
end

%% Update nonzero weights until convergence
if ~isempty(Omega)
    for n=3:iter
        w_old1=w;
        for i=Omega
            z(i)=KyX(i)-KXX(i,:)*w+KXX(i,i)*w(i);
            if z(i)>lambda
                w(i) = z(i)-lambda;
            elseif z(i)<-lambda
                w(i) = z(i)+lambda;
            else
                w(i) = 0;
            end
        end
        W=[W w];
        
        Dw=w-w_old1;
        DwiNorm = norm(Dw,2);
        
        error1=DwiNorm/norm(w_old1,2);
        if error1 < exit_tol
            fprintf('nonzero weights achieve convergence at iter %d\n',n);
            n_nonzero=n;
            break
        end       
    end
else
    n_nonzero=3;
end

%% Skip zero weights
for n=n_nonzero:iter
    w_old2=w;
    for i=1:atoms
        if i==1
            DwiNorm=sqrt(DwiNorm^2-Dw(i)^2);
        else
            DwiNorm=sqrt(DwiNorm^2-Dw(i)^2+Dw(i-1)^2);
        end
        Theta=KXX_rowNorms(i)*DwiNorm;
        z_upper=z(i)+Theta;
        z_lower=z(i)-Theta;
        if z_upper<lambda && z_lower>-lambda
            w(i) = 0;
        else
            z(i)=KyX(i)-KXX(i,:)*w+KXX(i,i)*w(i);
            if z(i)>lambda
                w(i) = z(i)-lambda;
            elseif z(i)<-lambda
                w(i) = z(i)+lambda;
            else
                w(i) = 0;
            end
        end
        Dw(i)=w(i)-w_old2(i);
    end
    DwiNorm=sqrt(DwiNorm+Dw(i)^2); % DwiNorm=norm(Dw,2);
    W=[W w];
    
    error2=norm(w-w_old2,2)/norm(w_old2,2);
    if error2 < exit_tol
        fprintf('KCD_ffast reached exit tolerance at iter %d\n',n);
        break
    end
end
end

